OG |Market Modern Website
=========================
Modern responsive landing page using the supplied OG Market logo.

Files:
- index.html
- style.css
- script.js
- assets/ogmarket-logo.jpg

Open index.html directly in a browser or upload the folder to your web host.
The Discord buttons link to https://discord.gg/ogmarket.
